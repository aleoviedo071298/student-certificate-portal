<?php
session_start();
if(!isset($_SESSION['usuario'])){
    header("Location: ../index.php");
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestor de alumnos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body>
    <navbar default-expand="lg" class="navbar navbar-expand-lg navbar-light bg-light"> 
        <a class="navbar-brand" href="../secciones/index.php">Gestor de alumnos</a> 
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation"> 
            <span class="navbar-toggler-icon"></span> 
        </button> 
        <div class="collapse navbar-collapse" id="navbarNav"> 
            <ul class="navbar-nav"> 
                <li class="nav-item active"> 
                    <a class="nav-link" href="../secciones/index.php">Inicio</a> 
                </li> 
                <li class="nav-item"> 
                    <a class="nav-link" href="../secciones/vista_alumnos.php">Alumnos</a> 
                </li> 
                <li class="nav-item"> 
                    <a class="nav-link" href="../secciones/vista_cursos.php">Cursos</a> 
                </li> 
                <li class="nav-item"> 
                    <a class="nav-link" href="../secciones/cerrar.php">Cerrar sesion</a> 
                </li> 
                 
            </ul> 
        </div> 
    </navbar> 